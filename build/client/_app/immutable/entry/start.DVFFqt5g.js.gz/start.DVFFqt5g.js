import{b as a}from"../chunks/entry.B3oirdxR.js";export{a as start};
