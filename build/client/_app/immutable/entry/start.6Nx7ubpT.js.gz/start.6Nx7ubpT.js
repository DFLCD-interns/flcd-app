import{b as a}from"../chunks/entry.CL2sXVfz.js";export{a as start};
