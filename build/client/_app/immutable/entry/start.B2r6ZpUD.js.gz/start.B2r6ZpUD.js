import{b as a}from"../chunks/entry.DBH_V7Gc.js";export{a as start};
